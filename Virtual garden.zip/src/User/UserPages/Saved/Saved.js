import React from 'react'

function Saved() {
  return (
    <div>Saved</div>
  )
}

export default Saved