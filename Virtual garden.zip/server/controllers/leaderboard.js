import User from "../schema/user.js";
import { Garden } from "../schema/garden.js";

export const leaderBoard = async (req, res) => {
    try {
        const leader = await User.find({ userType: "user" });
        const myPromise = new Promise((resolve, reject) => {
            let arr = []
            leader.map(async (item) => {
                const garden = await Garden.find({ userId: item._id })
                arr.push({ garden: garden, user: item })
                if (leader.length === arr.length) {
                    return resolve(arr)
                } 
            })
        });

        myPromise
            .then((value) => value)
            .then((val) => res.status(200).json(val))

    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal server error" });
    }
};

 