import { Garden } from "../schema/garden.js";
import User from "../schema/user.js"

export const createGarden = async (req, res) => {
  try {
    const userId = req.body.userId; // Get the user's ID
    const gardenName = req.body.gardenName; // Get the garden name

    // Check if the user exists
    const user = await User.findById(userId);
    if (!user) {
      return res.status(400).json({ message: "User not found." });
    }

    // Count the number of active gardens for the user
    const activeGardensCount = await Garden.countDocuments({ userId, isActive: true });

    // Check if the user has reached the maximum limit of active gardens
    if (activeGardensCount >= 4) {
      return res.status(400).json({ message: "You have reached the maximum limit of active gardens. Deactivate one before creating a new one." });
    }

    // Create a new garden document
    const newGarden = await Garden.create({
      userId,
      name: gardenName,
      isActive: true, // Set the garden as active initially
      squares: new Array(30).fill({}),
      completedGoals: [],
    });

    return res.status(201).json({ message: "Garden created successfully.", garden: newGarden });
  } catch (error) {
    // Handle any errors that occur during garden creation
    console.error('Error:', error);
    return res.status(500).json({ message: "An error occurred while creating the garden." });
  }
}


export const getAllgarden = async (req, res) => {
  try {
    const userId = req.params.userId; // Get the user's ID from the URL

    // Retrieve all active gardens for the user
    const activeGardens = await Garden.find({ userId, isActive: true });

    // Return the list of active gardens in the response
    return res.status(200).json({ activeGardens });
  } catch (error) {
    // Handle any errors that occur during the retrieval
    console.error('Error:', error);
    return res.status(500).json({ message: "An error occurred while retrieving active gardens." });
  }
}

export const getOnegarden = async (req, res) => {
  try {
    const gardenId = req.params.gardenId; // Get the garden ID from the URL

    // Retrieve the garden by its ID
    const garden = await Garden.findById(gardenId);
    if (!garden) {
      return res.status(404).json({ message: "Garden not found." });
    }

    // Return the garden in the response
    return res.status(200).json({ garden });
  } catch (error) {
    // Handle any errors that occur during the retrieval
    console.error('Error:', error);
    return res.status(500).json({ message: "An error occurred while retrieving the garden." });
  }
}

export const deletegarden = async (req, res) => {
  try {
    const gardenId = req.params.id;
    // Assuming you have a Garden model
    const deletedGarden = await Garden.findByIdAndDelete(gardenId);

    if (!deletedGarden) {
      return res.status(404).json({ error: 'Garden not found' });
    }

    res.json({ message: 'Garden deleted successfully', deletedGarden });
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
};