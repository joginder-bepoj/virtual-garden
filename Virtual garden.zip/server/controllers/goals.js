import { Goal, Garden } from "../schema/garden.js";
export const createGoals = async (req, res) => {
  try {
    const { name, description, goalType, frequency,  endDate, gardenId, userId } = req.body;
    const startDate = new Date()

    // Validate required fields
    if (!name || !description || !goalType || !frequency || !gardenId || !userId) {
      return res.status(400).json({ error: 'Please provide all required fields.' });
    }

    // Create a new goal
    const newGoal = new Goal({
      name,
      description,
      goalType,
      frequency,
      startDate,
      endDate,
      gardenId,
      userId
    });

    // Save the goal to the database
    await newGoal.save();

    // Send a success response
    res.status(201).json(newGoal);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}

  export const goalCompleted = async (req, res) => {
    const { gardenId, goalId } = req.params;

    try {
      const garden = await Garden.findById(gardenId);
  
      if (!garden) {
        return res.status(404).json({ message: "Garden not found." });
      }
  
      // Find the goal within the garden's goals array
      const goalIndex = garden.goals.findIndex((goal) => goal._id === goalId);
  
      if (goalIndex === -1) {
        return res.status(404).json({ message: "Goal not found within the garden." });
      }
  
      // Mark the goal as completed
      garden.goals[goalIndex].isCompleted = true;
  
      // Save the updated garden
      const updatedGarden = await garden.save();
      res.json(updatedGarden);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

export const getGoalsByUser = async (req, res) =>{
  const { userId } = req.params;
  try {
    const goals = await Goal.find({ userId });

    // Filter goals based on garden availability
    const filteredGoals = await Promise.all(
      goals.map(async (goal) => {
        const garden = await Garden.findOne({ _id: goal.gardenId });
        if (garden) {
          return goal;
        }

        return null;
      })
    );

    // Remove null values from the array
    const finalGoals = filteredGoals.filter((goal) => goal !== null);

    // Send the filtered goals data to the client
    res.status(200).json(finalGoals);
  } catch (err) {
    console.log(err)
  }
}