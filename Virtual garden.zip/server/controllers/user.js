import User from "../schema/user.js"
import bcrypt from "bcrypt"
import dotenv from "dotenv"
import { Garden, Goal } from "../schema/garden.js"

dotenv.config()


export const registerUser = async (req, res) =>{
    try {
        const {email, name, userName, userPassword, confirmPassword, number, dob} = req.body;

        const otp = generateOTP();
        const otpExpiredTime = new Date();
        otpExpiredTime.setMinutes(otpExpiredTime.getMinutes() + 15);

        const existingUser = await User.findOne({email})

        if(existingUser){
          return  res.status(400).json({
                message: "User email already exists. Please login to your account"
            })
        }

        const userNameAvail = await User.findOne({userName})
        
        if(userNameAvail){
         return res.status(400).json({
              message: "UserName already exists. Please choose another userName"
          })
        }

        const userNumber = await User.findOne({number})
        if(userNumber){
          return res.status(400).json({
               message: "Mobile number already exists. Please use another number"
           })
         }
       

        if(userPassword !== confirmPassword){
          return res.status(400).json({
            message: "Passwords are not matching"
          })
        }

        let password = bcrypt.hashSync(userPassword, 10)

      if(password){
          const newUser = await User.create({email, name, userName, password, number, dob, otp, otpExpiredTime})
          
        return res.status(201).json({message: "user created successfully", user: newUser})
      }
       
    } catch (err) {
        console.log(err)
        res.status(500).json({error: "Error from server side"})
    }
}

export const loginUser = async (req, res) =>{
    const {email, userPassword} = req.body

    try {
        const user = await  User.findOne({email})

        if(!user){
          return res.status(400).json({message: "Email not exists plaese Register"})
        }

        if (user.isOtpVerified) {
            let hashPassword = await bcrypt.compareSync(userPassword, user.password)

            if(!hashPassword){
              return res.status(400).json({message: "Password does not match"})
            }
            const {password, otpExpiredTime, isOtpVerified, ...other} = user._doc

            // let token = jwt.sign({
            //   data: other,
            //   exp: Math.floor(Date.now() / 1000) + (60 * 60) //1hour
            // }, process.env.JWT_KEY)

            res.status(200).json({other })
        }else {
            res.status(400).json({message: "Otp is not verified please verify the otp"})
        }
    } catch (err) {
        console.log(err)
        res.status(500).json({
            error: "An error occured at server"
        })
    }
}


export const updateUser = async (req, res) =>{
  const id = req.params.id;
  const {street, city, zipcode, state} = req.body

  try {
    const user = await User.findByIdAndUpdate(id, {
      street: street,
      city: city,
      state: state,
      zipcode: zipcode
    }, {new: true})

    if(!user){
      return res.status(404).json({error: "User not found"})
    }

    res.status(200).json(user)
    
  } catch (error) {
    console.log(error);
    res.status(500).json({error: "Internal server error"})
  }
}

export const verifyUser = async (req, res) => {
    try {
      const {email, otp} = req.body; 
  
      // Find the user with the given ID
      const user = await User.findOne({ email });

      if (user.otp === Number(otp)) {
        // Check if the OTP has expired
        if (user.otpExpiredTime && new Date() <= new Date(user.otpExpiredTime)) {
          // OTP is correct and not expired, mark the user as verified
          user.isOtpVerified = true;
          user.otp = undefined; // Clear the OTP from the database
          user.otpExpirationTime = undefined; // Clear the OTP expiration time
          await user.save();
          return res.status(200).json({ message: "User verified successfully." });
        }
      }
  
      // If the OTP is incorrect or expired, generate a new OTP and expiration time
      // const newOTP = generateOTP();
      // const newExpirationTime = new Date();
      // newExpirationTime.setMinutes(newExpirationTime.getMinutes() + 15);
  
      // Update the user's document with the new OTP and expiration time
      // user.otp = newOTP;
      // user.otpExpiredTime = newExpirationTime;
      // await user.save();
  
  
      return res.status(400).json({ message: "Invalid or expired OTP. A new OTP has been sent to your email." });
    
    } catch (error) {
      console.error('Error:', error);
      return res.status(500).json({ message: "An error occurred while verifying the user." });
    }
}


function generateOTP() {
    return Math.floor(100000 + Math.random() * 900000);
}

export const getAllUsers = async (req, res) =>{
  try {
    const users = await User.find({userType: 'user'}).sort({ createdAt: -1 })
    if(users.length === 0){
      return res.status(400).json({error: "No user found"})
    }

    res.status(200).json(users)
  } catch (error) {
    console.log(error)
    res.status(500).json({error: "Internal server error"})
  }
}

export const getSingleuser = async (req, res) =>{
  const id = req.params.id
  try {
    const user = await User.findById(id)
    if(!user){
      return res.status(400).json({error: "No user found with the provided id"})
    }
    const userGradens = await Garden.find({userId: id})
    const gardenLength = userGradens.length

    const goals = await Goal.find({ userId: id });
    const goalsLength = goals.length

    res.status(200).json({user, gardenLength, goalsLength})
  } catch (error) {
    console.log(error)
    res.status(500).json({error: "Internal server error"})
  }
}

export const deleteSingleUser = async (req, res)=>{
  const id = req.params.id;
  try {
    // const result = await User.deleteOne({ _id: id });
    const result = await User.findByIdAndDelete(id)

    if (result.deletedCount === 0) {
     return res.status(404).send('User not found');
    } else {
     return res.status(200).send('User deleted successfully');
    }
  } catch (error) {
    res.status(500).json({error: "Internal server error"})
  }
}


export const deactivateUser = async (req, res) =>{
  const id = req.params.id;
  try {
    const user = await User.findByIdAndUpdate(id, {isUserDeactivated : true}, {new: true})

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.status(200).send("User is deactivated")
  } catch (error) {
    console.log(error)
    res.status(500).json({error: "Internal server error"})
  }
}

export const activateUser = async (req, res) =>{
  const id = req.params.id;

  try {
    const user = await User.findByIdAndUpdate(id, {isUserDeactivated : false}, {new: true})

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.status(200).send("User is deactivated")
  } catch (error) {
    console.log(error)
    res.status(500).json({error: "Internal server error"})
  }
}

