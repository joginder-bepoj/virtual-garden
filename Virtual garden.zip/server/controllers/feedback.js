// import feedback from "../schema/feedback.js";
import Feedback from "../schema/feedback.js";

export const queryFeedback = async (req, res) => {
    const {name, email, status, query, subject} = req.body
    try {
        const feedback = new Feedback({
            name,
            email,
            status,
            query,
            subject
          });
      
          await feedback.save(); 
          res.status(201).json(feedback);
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "An error occurred while creating the Query." });
    }
}

export const getQueryFeedback = async (req, res) =>{
    try {
        const getfeedback = await Feedback.find();
        return res.status(200).json( getfeedback );
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "An error occurred while creating the Query." });
    }
}

export const getOneQueryFeedback = async (req, res) =>{
    try {
        const getfeedback = await Feedback.findById(req.params.id);
        return res.status(200).json( getfeedback );
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "An error occurred while creating the Query." });
    }
}

export const deleteFeedback = async (req, res) =>{
    try {
        await Feedback.findByIdAndDelete(req.params.id)
        return res.status(200).json({message: "feedback deleted sucessfully"})
    } catch (error) {
        console.log(error);
        return res.status(500).json({message: "An error ocurred while creating the Query>"})
    }
}

export const updateQueryFeedback = async (req, res) =>{ 
    const {status, reply} = req.body
    try {
        const getfeedback = await Feedback.findByIdAndUpdate(req.params.id, {status:status, reply:reply});
        return res.status(200).json( getfeedback );
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "An error occurred while creating the Query." });
    }
}