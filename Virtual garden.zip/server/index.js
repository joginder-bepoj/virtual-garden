import express, { query } from "express"
import mongoose from 'mongoose';
import dotenv from "dotenv"
import bodyParser from "body-parser";
import cors from "cors"
import userRoutes from "./routes/users.js"
import gardenRoutes from "./routes/garden.js"
import feedbackRoutes from "./routes/feedback.js";
import { leaderBoard } from "./controllers/leaderboard.js";

dotenv.config()

const app = express()
const port = 8080


// middlewares
app.use((express.json()))
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors('*'))

// mongo connection
mongoose.connect(process.env.MONGO_URI)
.then(() => console.log('Connected!'))
.catch((err)=> console.log(err));


app.use("/api/user", userRoutes)
app.use("/api/garden", gardenRoutes)

app.use("/api/feedback", feedbackRoutes)
app.get("/api/leaderboard", leaderBoard)


app.listen(port, ()=>{
    console.log("server started at port number" + port)
})

// http://192.168.1.102:8080/api/user/register