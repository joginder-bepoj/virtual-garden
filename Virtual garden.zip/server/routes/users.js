import express from "express";
import { activateUser, deactivateUser, deleteSingleUser,  getAllUsers, getSingleuser, loginUser, registerUser, updateUser, verifyUser } from "../controllers/user.js";

const router =  express.Router()

router.post("/register", registerUser)
router.post("/login", loginUser)
router.post("/verify", verifyUser)
router.put("/update/:id", updateUser)
// admin
router.get("/getall", getAllUsers)
router.get("/getone/:id", getSingleuser)
router.delete("/delete/:id", deleteSingleUser)
router.put("/deactive/:id", deactivateUser)
router.put("/active/:id", activateUser)

export default router