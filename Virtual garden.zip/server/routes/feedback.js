import express  from "express";
import { deleteFeedback, getOneQueryFeedback, getQueryFeedback, queryFeedback, updateQueryFeedback } from "../controllers/feedback.js";

const router = express.Router()

router.post("/create", queryFeedback)
router.get("/get", getQueryFeedback)
router.delete("/del/:id" ,deleteFeedback)
router.get("/get-one/:id", getOneQueryFeedback)
router.put("/update/:id", updateQueryFeedback)

export default router