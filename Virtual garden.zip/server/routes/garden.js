import express from "express"
import {createGarden, deletegarden, getAllgarden, getOnegarden} from "../controllers/garden.js"
import { createGoals, getGoalsByUser, goalCompleted } from "../controllers/goals.js"




const router = express.Router()

router.post("/create",  createGarden)
router.get("/getAll/:userId",  getAllgarden)
router.get("/get/:gardenId", getOnegarden)
router.delete("/delete/:id", deletegarden)

// goals
router.post("/goals/create", createGoals)
router.put("/:gardenId/goals/:goalId/completed", goalCompleted)
router.get("/goals/get/:userId", getGoalsByUser)




export default router