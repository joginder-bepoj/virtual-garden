import mongoose from "mongoose";

// Define the Feedback schema
const feedbackSchema = new mongoose.Schema({
    name: {type: String, required: true},
    email: {type: String, required: true},
    status: {type: String, required: true},
    query: {type: String, required: true},
    subject: {type: String, required: true},
    reply: {type: String}
}, {timestamps:true});

export default mongoose.model('Feedback', feedbackSchema);