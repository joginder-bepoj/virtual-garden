import mongoose from "mongoose";
const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required : true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    userName: {
        type: String,
        unique: true,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    number: {
        type: Number,
        required: true,
        unique: true
    },
    dob: {
        type: Date,
        required: true
    },
    otp: {
        type: Number,
        length: 6
    },
    isOtpVerified: {
        type: Boolean,
        default: false
    },
    otpExpiredTime: {
        type: Date
    },
    userType: {
        type: String,
        default: "user"
    },
    isUserDeactivated:{
        type: Boolean,
        default: false
    },
    street:{
        type: String
    },
    city:{
        type: String
    },
    state:{
        type: String
    },
    zipcode:{
        type: String
    }
}, {timestamps: true})


export default mongoose.model("User", userSchema)