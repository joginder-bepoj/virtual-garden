import mongoose from "mongoose";

const leaderSchema = new mongoose.Schema({
    
});

const Leaderboard = mongoose.model("Leader", leaderSchema);
export { Leaderboard };
