import mongoose from "mongoose";

// Define the Goal schema
const goalSchema = new mongoose.Schema({
  name: String,
  description: String,
  goalType: String,
  isCompleted: {type: Boolean, default: false},
  frequency: {
    type: String,
    enum: ['daily', 'weekly', 'monthly'],
  },
  startDate: Date,
  endDate: Date,
  gardenId: String,
  userId: String
});

// Define the Plant schema
const plantSchema = new mongoose.Schema({
  name: String,
  level: Number,
});

// Define the Garden schema
const gardenSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // User who owns the garden
  name: String,
  isActive: Boolean,
  squares: [
    {
      goal: goalSchema, // Each square can have a goal
      plant: plantSchema, // Each square can have a plant
    },
  ],
});

// Create models for Goal, Plant, and Garden
const Goal = mongoose.model('Goal', goalSchema);
const Plant = mongoose.model('Plant', plantSchema);
const Garden = mongoose.model('Garden', gardenSchema);

export { Goal, Plant, Garden };