import jwt from "jsonwebtoken";
import dotenv from "dotenv"

dotenv.config()

const auth = async (req, res, next) =>{

    try {
        let token = await req.headers.authorization?.split(" ")[1]
        if(!token){
          return res.status(401).json({message: "need a token to access the content"})
        }

        let verifyToken = jwt.verify(token, process.env.JWT_SECRET)
   
        if(verifyToken){
            next()
        }else{
            return res.status(401).json({message: "Inavlid token"})
        }
    } catch (error) {
        res.status(401).json({message: "Inavlid token"})
    }
}

export default auth